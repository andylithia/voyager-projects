//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HP12c_c.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HP20b_C_DIALOG              102
#define IDS_STRING102                   102
#define IDS_STRING103                   103
#define IDR_MAINFRAME                   129
#define IDI_ICON                        128
#define IDR_MENU1                       137
#define IDB_BITMAP1                     138
#define IDR_MENU2                       139
#define IDR_MENU3                       140
#define IDB_BITMAP2                     141
#define IDC_VIRTUAL_LCD                 1040
#define IDC_STATIC_BG                   1051
#define IDC_STATIC_VER_INFO             1052
#define IDC_STATIC4                     1053
#define ID_HP20b_RESETSTATE             32771
#define ID_HP20b_ON                     32772
#define ID_HP20b_ONAF                   32778
#define ID_HP20b_OND                    32779
#define ID_HP20b_ONC                    32780
#define ID_HP20b_ONMINUS                32781
#define ID_HP20b_ONPLUS                 32782
#define ID_HP20b_COPYTOCLIPBOARD        32783
#define ID_HP20b_PCCALC1                32784
#define ID_HP20b_PCCALC3                32786
#define ID_HP20b_PCCALC4                32787
#define ID_HP20b_PCCALC5                32788
#define ID_HP20b_TESTSYSTEM             32789
#define ID_TESTSYSTEM_PC                32790
#define ID_HP20b_EXIT                   32791
#define ID_Menu32792                    32792
#define ID_HP20b_SHOWCAPTION            32793
#define ID_CALCULATOR_                  32794
#define ID_CALCULATOR_RESET             32795
#define ID_CALCULATOR_EXIT              32796
#define ID_CALCULATOR_HIDE_TITLE_BAR    32797
#define ID_EDIT_                        32798
#define ID_EDIT_PASTENUMBER             32799
#define ID_EDIT_COPY_NUMBER             32800
#define ID_EDIT_PASTE_NUMBER            32801
#define ID_EDIT_COPYSCREENTOCLIPBOARD   32802
#define ID_SPECIALKEYS_ON               32803
#define ID_SPECIALKEYS_ON32804          32804
#define ID_SPECIALKEYS_ON32805          32805
#define ID_HELP_HP                      32806
#define ID_HELP_ABOUT                   32807
#define ID_HELP_HP20BBUSINESSCONSULTANT 32808
#define ID_BUY                          32809
#define ID_HELP_ABOUTBOX                32810
#define ID_HP20b_SHOWCAPTION_MENU       32811
#define ID_HP20b_PCCALC2                32812
#define ID_CALCULATOR_ASSIGNASDEFAULTHPCALCULATOR 32813
#define ID_CALCULATOR_MANAGEHPCALCULATOREMULATORS 32814
#define ID_HELP_ADVANCEDHELP            32815

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32816
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
